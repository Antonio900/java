package kr.ac.bonwoo.model;

import lombok.Data;

@Data
public class SemesterPoint {
	
	private int year;
	private int semester;
	private int grade;
	
	public SemesterPoint(){
	
	}
	
	public SemesterPoint(int year, int semester, int grade){
		this.year = year;
		this.semester = semester;
		this.grade = grade;
	}
}