package kr.ac.bonwoo.service;

import java.util.List;

import kr.ac.bonwoo.dao.GradeDAO;
import kr.ac.bonwoo.model.SemesterPoint;
import kr.ac.bonwoo.model.Subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GradeService {

	private GradeDAO gradeDAO;
	
	@Autowired
	public void setDAO(GradeDAO gradeDAO){
		this.gradeDAO = gradeDAO;
	}	
	
	public int GetSemesterPoint(int year, int semester){
		return gradeDAO.GetSemesterPoint(year, semester);
	}
	
	public List<Subject> getSubjects(int year, int semester){
		return gradeDAO.getSubjects(year, semester);
	}
	
	public int getSubjectTypeGrade(String subjectType){
		return gradeDAO.getSubjectTypeGrade(subjectType);
	}
	
}