package kr.ac.bonwoo.dao;

import java.util.List;

import javax.sql.DataSource;

import kr.ac.bonwoo.model.Subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.jdbc.core.JdbcTemplate;

@Component("courseDAO")
public class CourseDAO {

	private JdbcTemplate jdbcTemplateObject;
	
	@Autowired
	public void setDataSource(DataSource dataSource){
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	public void insert(Subject subject){
		try{
			String subjectCode = subject.getSubjectCode();
			String subjectName = subject.getSubjectName();
			String subjectType = subject.getSubjectType();
			int grade = subject.getGrade();
			
			String query = "insert into subjecttable(year,semester,subjectCode,subjectName,subjectType,grade) values(2018,1,?,?,?,?)";
			jdbcTemplateObject.update(query, new Object[]{subjectCode,subjectName, subjectType, grade});
		}catch(Exception e){
			System.out.println("CourseDAO insert Exception");
			e.printStackTrace();
		}
	}
	
	public List<Subject> getRegisterSubjects(){
		try{
			String query = "select subjectCode, subjectName, subjectType, grade  from subjecttable where year=? and semester=?";
			return jdbcTemplateObject.query(query, new Object[]{2018, 1}, new SubjectMapper());			
		}catch(Exception e){
			System.out.println("CourseDAO getRegisterSubjects Exception");
			e.printStackTrace();
		}
		return null;
	}
	
}
