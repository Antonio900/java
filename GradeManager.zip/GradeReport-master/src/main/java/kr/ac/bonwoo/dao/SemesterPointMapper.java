package kr.ac.bonwoo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import kr.ac.bonwoo.model.SemesterPoint;

import org.springframework.jdbc.core.RowMapper;

public class SemesterPointMapper implements RowMapper<SemesterPoint>{

	@Override
	public SemesterPoint mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		SemesterPoint semesterPoint = new SemesterPoint();
		
		semesterPoint.setYear(rs.getInt("year"));
		semesterPoint.setSemester(rs.getInt("semester"));
		semesterPoint.setGrade(rs.getInt("grade"));
		
		return semesterPoint;
	}
}