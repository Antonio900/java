package kr.ac.bonwoo.dao;

import java.util.List;

import javax.sql.DataSource;

import kr.ac.bonwoo.model.SemesterPoint;
import kr.ac.bonwoo.model.Subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component("gradeDAO")
public class GradeDAO {

	private JdbcTemplate jdbcTemplateObject;
	
	@Autowired
	public void setDAO(DataSource dataSource){
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}
	
	public int GetSemesterPoint(int year, int semester){
		try{	
			String query = "select sum(case when year=? and semester=? then grade end) as grade from subjecttable ";
			return jdbcTemplateObject.queryForObject(query, new Object[]{year, semester}, Integer.class);
		}catch(Exception e){
			System.out.println("GradeDAO GetallSemesterPoint Exception");
			e.printStackTrace();
		}
		return 0;
	}
	 
	public List<Subject> getSubjects(int year, int semester){
		try{
			String query = "select subjectCode, subject, type, grade  from subjecttable where year=? and semester=?";
			return jdbcTemplateObject.query(query, new Object[]{year, semester}, new SubjectMapper());
		}catch(Exception e){
			System.out.println("GradeDAO getSubjects Exception ");
			e.printStackTrace();
		}
		return null;
	}
	
	public int getSubjectTypeGrade(String subjectType){
		try{
			String query = "select sum(case when type=? then grade end)as grade from subjecttable";
			return jdbcTemplateObject.queryForObject(query, new Object[]{subjectType}, Integer.class);
		}catch(Exception e){
			System.out.println("GradeDAO getSubjectTypeGrade Exception ");
			e.printStackTrace();
		}
		return 0;
	}
	
}