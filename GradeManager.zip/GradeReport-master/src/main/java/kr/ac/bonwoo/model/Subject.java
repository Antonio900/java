package kr.ac.bonwoo.model;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.NotEmpty;

import lombok.Data;

@Data
public class Subject {
	
	@Size(min=7, max=7, message="Check your subject Code - must be 7 words")
	@Pattern(regexp="^[A-Z]{3}[0-9]{4}$", message="Check your subject Code")
	@NotEmpty(message = "does not empty subjectCode")
	private String subjectCode;
	
	@Size(min=4, max=20, message="Check your subject Name")
	@NotEmpty(message = "does not empty subjectCode")
	private String subjectName;
	
	@NotEmpty(message = "does not empty subjectCode")
	private String subjectType;

	@Digits(integer=1, fraction=0)
	@Min(value=1, message="min value = 1")
	@Max(value=3, message="max value = 3")
	@NotNull(message = "does not empty subjectCode")
	private int grade;
	
	public Subject(){
		
	}
	
	public Subject(String subjectCode, String subjectName, String subjectType, int grade){
		this.subjectCode = subjectCode;
		this.subjectName = subjectName;
		this.subjectType = subjectType;
		this.grade = grade;
	}	
}