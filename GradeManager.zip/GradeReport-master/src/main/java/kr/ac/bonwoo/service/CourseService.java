package kr.ac.bonwoo.service;

import java.util.List;

import kr.ac.bonwoo.dao.CourseDAO;
import kr.ac.bonwoo.model.Subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseService {

	private CourseDAO courseDAO;

	@Autowired
	public void setDAO(CourseDAO courseDAO) {
		this.courseDAO = courseDAO;
	}

	public void insert(Subject subject) {
		courseDAO.insert(subject);
	}

	public List<Subject> getRegisterSubjects() {
		return courseDAO.getRegisterSubjects();
	}

}