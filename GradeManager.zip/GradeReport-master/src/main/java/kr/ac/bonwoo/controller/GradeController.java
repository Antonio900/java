package kr.ac.bonwoo.controller;

import java.util.List;

import java.util.ArrayList;
import kr.ac.bonwoo.model.SemesterPoint;
import javax.servlet.http.HttpServletRequest;

import kr.ac.bonwoo.model.Subject;
import kr.ac.bonwoo.service.GradeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GradeController {

	private GradeService gradeService;
	
	@Autowired
	public void setService(GradeService gradeService){
		this.gradeService = gradeService;
	}
	
	@RequestMapping(value="/semesterPoint")
	public String showSemesterPoint(Model model){

		List<SemesterPoint> allSemesterPoints = new ArrayList<SemesterPoint>();
		
		for(int year=2013; year<2017; year++){
			for(int semester = 1; semester<4; semester++){	
				int point = gradeService.GetSemesterPoint(year,semester);	
				SemesterPoint semesterPoint = new SemesterPoint(year, semester, point);

				allSemesterPoints.add(semesterPoint);
			}
		}	
		model.addAttribute("allSemesterPoints", allSemesterPoints);
	
		return "semesterPoint";
	}
	

	@RequestMapping(value="/details")
	public String showDetails(HttpServletRequest request, Model model){
	
		int year = Integer.parseInt(request.getParameter("year"));
		int semester = Integer.parseInt(request.getParameter("semester"));
	
		List<Subject> subjects = gradeService.getSubjects(year, semester);
		
		model.addAttribute("year", year);
		model.addAttribute("semester", semester);
		model.addAttribute("subjects", subjects);
		
		return "detailGrade";
	}
	
	@RequestMapping(value="/completePoint")
	public String showCompletePoint(Model model){
	
		List<Integer> gradeList = new ArrayList<Integer>();
		
		String[] subjectType = {"����","�ٱ�","����","����","����"};
		
		int sum = 0;
		for(int i=0; i<subjectType.length; i++){
			int subjectTypeGrade = gradeService.getSubjectTypeGrade(subjectType[i]);
			sum = sum + subjectTypeGrade;
			gradeList.add(subjectTypeGrade);
		}
		gradeList.add(sum);		
		
		model.addAttribute("gradeList", gradeList);
		
		return "completePoint";
	}
}