package kr.ac.bonwoo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import kr.ac.bonwoo.model.Subject;
import kr.ac.bonwoo.service.CourseService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CourseController {
	
	private CourseService courseService;
	
	@Autowired
	public void setService(CourseService courseService){
		this.courseService = courseService;
	}
	
	@RequestMapping(value="/registerCourse", method=RequestMethod.GET)
	public String showRegisterCourse(Model model){
		
		model.addAttribute(new Subject());
		
		return "registerCourse";
	}
	
	@RequestMapping(value="/doRegister")
	public String doRegisterCourse(HttpServletRequest request, @Valid Subject subject, BindingResult result){
		
		if(result.hasErrors()){
			System.out.println("form data does not validate");
			List<ObjectError> errors = result.getAllErrors();
			
			for(ObjectError error:errors)
				System.out.println(error.getDefaultMessage());
			return "registerCourse";
		}
		courseService.insert(subject);
		return "home"; 	
	}
	
	@RequestMapping(value="/inquiryRegisterCourse")
	public String showInquiryRegisterCourse(Model model){
		
		List<Subject> subjects = courseService.getRegisterSubjects();
		
		model.addAttribute("subjects", subjects);
		
		return "inquiryRegisterCourse";
	}
}
