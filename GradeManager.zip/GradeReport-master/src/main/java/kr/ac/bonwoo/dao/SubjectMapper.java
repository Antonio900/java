package kr.ac.bonwoo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import kr.ac.bonwoo.model.Subject;

import org.springframework.jdbc.core.RowMapper;

public class SubjectMapper implements RowMapper<Subject>{

	@Override
	public Subject mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Subject subject = new Subject();
		
				subject.setSubjectName(rs.getString("subjectName"));

subject.setSubjectType(rs.getString("subjectType"));

subject.setSubjectCode(rs.getString("subjectCode"));
				subject.setGrade(rs.getInt("grade"));
		
		return subject;
	}
}